<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Publication;
use App\Models\PublicationTarget;
use App\Models\Question;
use App\Models\Answer;
use Illuminate\Support\Facades\Auth;

class PublicationController extends Controller
{
    // Liste des publications pour l'utilisateur connecté
    public function index(Request $request)
{
    $user = Auth::user();
    $query = Publication::whereHas('targets', function($q) use ($user) {
        $q->where(function($w) use ($user) {
            $w->where('user_id', $user->id)
                ->orWhere('departement_id', $user->departement_id)
                ->orWhere(function($r) use ($user) {
                    $r->where('role', $user->getRoleNames()->first())
                      ->where('societe_id', $user->societe_id);
                })
                // Cas typeContrat temporaire : PAS de filtre société
                ->orWhere(function($t) use ($user) {
                    $t->where('typeContrat', $user->typeContrat);
                    if ($user->typeContrat !== "temporaire") {
                        $t->where('societe_id', $user->societe_id);
                    }
                });
        });
    })->with(['questions.answers', 'targets']);

    if (!$user->hasRole('RH')) {
        $query->where('statut', 'publie');
    } else if ($request->has('statut')) {
        $query->where('statut', $request->statut);
    }

    if ($request->has('type')) {
        $query->where('type', $request->type);
    }

    return response()->json($query->latest()->get());
}



    // Création d'une publication (news ou sondage)
    public function store(Request $request)
{
    $request->validate([
        'type'   => 'required|in:news,sondage',
        'titre'  => 'required|string|max:255',
        'texte'  => 'nullable|string',
        'questions' => 'array', // obligatoire pour un sondage
        'questions.*.question' => 'required_if:type,sondage|string',
        'questions.*.answers' => 'required_if:type,sondage|array|min:2',
        'targets' => 'required|array',
        'statut' => 'nullable|in:brouillon,publie,ferme',
    ]);

    $user = Auth::user();

    // Création publication
    $publication = Publication::create([
        'type' => $request->type,
        'titre' => $request->titre,
        'texte' => $request->texte,
        'created_by' => $user->id,
        'statut' => $request->statut ?? 'brouillon',
    ]);

    $targets = $request->targets;

    // user_ids
    if (!empty($targets['user_ids'])) {
        foreach ($targets['user_ids'] as $userId) {
            PublicationTarget::create([
                'publication_id' => $publication->id,
                'user_id' => $userId,
                'societe_id' => $user->societe_id,
            ]);
        }
    }
    // departements
    if (!empty($targets['departements'])) {
        foreach ($targets['departements'] as $depId) {
            PublicationTarget::create([
                'publication_id' => $publication->id,
                'departement_id' => $depId,
                'societe_id' => $user->societe_id,
            ]);
        }
    }
    // roles
    if (!empty($targets['roles'])) {
        foreach ($targets['roles'] as $role) {
            PublicationTarget::create([
                'publication_id' => $publication->id,
                'role' => $role,
                'societe_id' => $user->societe_id,
            ]);
        }
    }
    // typeContrat
    if (!empty($targets['typeContrat'])) {
        // Cas temporaire : PAS de filtre société
        if ($targets['typeContrat'] === "temporaire") {
            PublicationTarget::create([
                'publication_id' => $publication->id,
                'typeContrat' => $targets['typeContrat'],
                'societe_id' => null,
            ]);
        } else {
            PublicationTarget::create([
                'publication_id' => $publication->id,
                'typeContrat' => $targets['typeContrat'],
                'societe_id' => $user->societe_id,
            ]);
        }
    }

    // Si sondage : questions + answers
    if ($publication->type === 'sondage' && !empty($request->questions)) {
        foreach ($request->questions as $questionData) {
            $question = Question::create([
                'publication_id' => $publication->id,
                'question' => $questionData['question'],
            ]);
            foreach ($questionData['answers'] as $answerText) {
                Answer::create([
                    'question_id' => $question->id,
                    'answer' => $answerText,
                ]);
            }
        }
    }

    // NOTIFICATION OneSignal
    $this->notifyTargets($publication);

    return response()->json(['message' => 'Publication créée !', 'id' => $publication->id], 201);
}

/**
 * Envoie les notifications OneSignal aux utilisateurs ciblés.
 */
protected function notifyTargets($publication)
{
    // On va chercher tous les user_id ciblés
    $targets = $publication->targets;
    $userIds = [];

    foreach ($targets as $target) {
        // Par user direct
        if ($target->user_id) $userIds[] = $target->user_id;
        // Par département + société
        if ($target->departement_id) {
            $ids = \App\Models\User::where('departement_id', $target->departement_id);
            if ($target->societe_id) $ids = $ids->where('societe_id', $target->societe_id);
            $userIds = array_merge($userIds, $ids->pluck('id')->toArray());
        }
        // Par rôle + société
        if ($target->role) {
            $ids = \App\Models\User::role($target->role);
            if ($target->societe_id) $ids = $ids->where('societe_id', $target->societe_id);
            $userIds = array_merge($userIds, $ids->pluck('id')->toArray());
        }
        // Par typeContrat
        if ($target->typeContrat) {
            $ids = \App\Models\User::where('typeContrat', $target->typeContrat);
            // Cas temporaire = toutes sociétés (PAS de where(societe_id))
            if ($target->typeContrat !== "temporaire" && $target->societe_id) {
                $ids = $ids->where('societe_id', $target->societe_id);
            }
            $userIds = array_merge($userIds, $ids->pluck('id')->toArray());
        }
    }
    // Envoie unique pour chaque user
    $userIds = array_unique($userIds);

    // Récupérer les PlayerIDs OneSignal des users
    $players = \App\Models\User::whereIn('id', $userIds)
        ->whereNotNull('onesignal_player_id')
        ->pluck('onesignal_player_id')
        ->toArray();

    if (count($players)) {
        $title = $publication->titre;
        $msg = $publication->texte ?? 'Nouvelle publication';
        $this->sendOneSignal($players, $title, $msg);
    }
}

/**
 * Envoie une notif OneSignal à une liste de PlayerIDs
 */
protected function sendOneSignal($playerIds, $title, $body)
{
    $content = [
        "en" => $body,
        "fr" => $body,
    ];
    $headings = [
        "en" => $title,
        "fr" => $title,
    ];
    $fields = [
        'app_id' => env('ONESIGNAL_APP_ID'),
        'include_player_ids' => $playerIds,
        'headings' => $headings,
        'contents' => $content,
    ];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Basic ' . env('ONESIGNAL_API_KEY'),
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
    curl_setopt($ch, CURLOPT_POST, TRUE);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}


    // Afficher une publication précise (avec questions et réponses)
    public function show($id)
    {
        $publication = Publication::with(['questions.answers', 'targets', 'createdBy'])->findOrFail($id);
        return response()->json($publication);
    }
}
